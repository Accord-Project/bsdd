var i, images = document.getElementsByTagName("img");

for(i = 0; i < images.length; i++) {
    images[i].className += "spotlight";
}